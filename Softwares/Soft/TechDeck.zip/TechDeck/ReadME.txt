**********************************************************
                     T E C H  D E C K
**********************************************************


Guide to configure the Stat Monitor Screen on your TechDeck

=======================
Step 1: Initial Setup
Go to the folder "Step1-Install"
Run the "configuration.bat" file as Administrator
(This will install HWiNFO, install or update Python, and install required Python packages)

=======================
Step 2: HWiNFO Configuration
Open HWiNFO (search in Start Menu or go to "C:\Program Files\HWiNFO64")
Go to Settings > General / User Interface tab
Enable the option: "Shared Memory Support [12-HOUR LIMIT]"
Click OK to save and close

=======================
Step 3: Final Launch
Make sure your MacroPad is connected via USB

Then go back to the main "TechDeck" folder
Run the "MacroPad.bat" file
(This will launch HWiNFO in sensor-only mode, start the Remote Sensor Monitor server on port 6969, and run the DisplayScript)

=======================
Note:
Steps 1 and 2 need to be done only once per system.
From the next time onward, simply run "MacroPad.bat" to start the Stat Monitor.




Enjoyy!!

Credits : TechnologyHell